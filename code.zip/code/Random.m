function [model] = Random(model,net,opts)
% Select Seed randomly (Baseline)

n = size(net.X,2);

%select seeds randomly
model.S = randsample(n,opts.K);
[model.spread,model.activeNodes,model.activeEdges] = calculateSpread(model.S,net.draw);

end


