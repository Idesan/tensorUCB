function [model] = TensorUCB(model,net,opts)
% Run TensorUCB algorithm: Tensor Bandits with UCB algorithm
% Initialize model.Phat(n x n), model.icov_w(d x d), model.icov_u(d x d), model.icov_v(d x d),
% model.bW(d x R), model.bU(d x R), model.bV(d x R)
% Parameters opts.c



K=opts.K;
R=opts.rank;
[d,n] = size(net.X);
normX = sum((net.X).^2,1);

%select seeds
model.S = selectSeeds(net.A, model.Phat, K, opts.oracleType,opts.temp_dir);
[model.spread,model.activeNodes,model.activeEdges] = calculateSpread(model.S,net.draw);
[~,activeNodeList] = getActivatedNode(model.activeNodes);

% Update parameters
for outIdx=1:length(activeNodeList)
    lf=activeNodeList(outIdx);
    receiversList = find(net.A(lf,:)~= 0);
    for inIdx =1:length(receiversList)
        rf=receiversList(inIdx);
        for i=1:R
            cxWt=ones(1,R-1);
            if opts.isContextual
                %cxWt= 1.0 ./ ( 1.0 + exp(-net.z'*model.W(:,[1:i-1 i+1:end])));
                cxWt=net.z'*model.W(:,[1:i-1 i+1:end]);
                % min cap to avoid error
                %{
                if cxWt<0
                    cxWt=0;
                end
                %}
            end
            Yr = model.activeEdges(lf,rf) - net.X(:,lf)'*model.U(:,[1:i-1 i+1:end])*diag(cxWt)*model.V(:,[1:i-1 i+1:end])'*net.X(:,rf);
            
            % Update W (d x R)
            if opts.isContextual
                model.icov_w{i}=r1Inv(model.icov_w{i}, net.z*model.U(:,i)'*net.X(:,lf), ...
                    net.z*model.U(:,i)'*net.X(:,lf), opts.sigma*((net.X(:,rf)'*model.V(:,i)).^2));
                model.bW{i}=model.bW{i}+net.z*model.U(:,i)'*net.X(:,lf)*Yr*(net.X(:,rf)'*model.V(:,i));
                model.W(:,i)= (model.icov_w{i}*model.bW{i});
                model.W(:,i)=normalizeMatrix(model.W(:,i));
            end
            
            cxWt=1.0;
            if opts.isContextual
                %cxWt= 1.0 ./ ( 1.0 + exp(-net.z'*model.W(:,i)));
                % min cap to avoid error
                cxWt=net.z'*model.W(:,i);
                %{
                if cxWt<0
                    cxWt=0;
                end
                %}
            end
            % Update U (d x R)
            model.icov_u{i}=r1Inv(model.icov_u{i}, net.X(:,lf), net.X(:,lf), ...
                opts.sigma*(cxWt*(net.X(:,rf)'*model.V(:,i))).^2);
            model.bU{i}=model.bU{i}+net.X(:,lf)*Yr*(cxWt)*(net.X(:,rf)'*model.V(:,i));
            model.U(:,i)= model.icov_u{i}*model.bU{i};
            model.U(:,i)=normalizeMatrix(model.U(:,i));
            % Update V (d x R)
            model.icov_v{i}=r1Inv(model.icov_v{i}, net.X(:,rf), net.X(:,rf), ...
                opts.sigma*(cxWt*(net.X(:,lf)'*model.U(:,i))).^2);
            model.bV{i}=model.bV{i}+net.X(:,rf)*Yr'*(cxWt)*(net.X(:,lf)'*model.U(:,i));
            model.V(:,i)=model.icov_v{i}*model.bV{i};
            model.V(:,i)=normalizeMatrix(model.V(:,i));
        end
    end
end

if (any(isnan(model.U(:))) )
    fprintf('NAN detected in the estimated U parameters\n');
end
if (any(isnan(model.V(:))) )
    fprintf('NAN detected in the estimated V parameters\n');
end
if opts.isContextual && (any(isnan(model.W(:))))
    fprintf('NAN detected in the estimated W parameters\n');
end
if ~opts.isContextual
    model.alpha=model.U*model.V';
end
% Update model's estimated influence probabilities
meanInfluence = zeros(n,n);
UCB=zeros(n,n);

% for all edges
[row,col,v] = find(net.A);
for i=1:length(v)
    lf = row(i); rf = col(i);
    meanInfluence(lf,rf) = 0.0;
    UCB(lf,rf) =0.0;
    for r=1:R
        cxWt=1.0;
        ctxVar = 0.0;
        if opts.isContextual
            %cxWt= 1.0 ./ ( 1.0 + exp(-net.z'*model.W(:,r)));
            % min cap to avoid error
            cxWt=net.z'*model.W(:,r);
            ctxVar = (net.z'*(model.icov_w{r}*net.z));
            %{
                if cxWt<0
                    cxWt=0;
                end
            %}
        end
        meanInfluence(lf,rf) = meanInfluence(lf,rf) + (cxWt*(net.X(:,lf)'* model.U(:,r)*model.V(:,r)'* net.X(:,rf)));
        UCB(lf,rf)= UCB(lf,rf) + (sqrt(ctxVar)) + (sqrt(net.X(:,lf)'*(model.icov_u{r}*net.X(:,lf))))...
            + (sqrt(net.X(:,rf)'*(model.icov_v{r}*net.X(:,rf))));
     end
end
% for r=1:R
%     ctxVar = 0.0;
%     if opts.isContextual
%         ctxVar = (net.z'*(model.icov_w{r}*net.z));
%     end
%     temp1=diag(net.X'*((model.icov_u{r})*net.X));
%     temp2=diag(net.X'*net.X);
%     UCB = UCB + sqrt(ctxVar) + sqrt(abs(temp1*temp2'));
% end   
UCB = (opts.c/R).* real(UCB) + 1e-6 * rand(n);
influenceUCB = meanInfluence + UCB;

% project onto [0,1] interval
model.Phat = min(max(influenceUCB,0),1);
model.Phat(1:n+1:end)=ones(n,1);


end


