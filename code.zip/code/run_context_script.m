% clear;
rng('default')
dataset = 'digg';
nseeds = 10; 
nrounds = 200;
nruns = 5;
uniqueId = '';


disp_settings = ['dataset:' dataset ' nseeds:' num2str(nseeds) ' nrounds:' num2str(nrounds) ' nruns:' num2str(nruns)];
disp(disp_settings);

% Parameter Tuning
opts.dataset = dataset;
opts.uniqueId = uniqueId;
opts.K=nseeds;
opts.d=10;
opts.d1=10; % Append
opts.nRuns=nruns;
opts.nIters=nrounds;

opts.use_cuda = false;
% if gpuDeviceCount == 1
%     opts.use_cuda = true;
% end

opts.cv=false;
opts.cv_iters=50; % cv on the first 50 iterations
opts.cv_models=[1]; % find best models among different ranks eg., [1:5], based on models selected below
opts.cv_best_model = zeros(1,opts.nRuns);
opts.cv_best_score = ones(1,opts.nRuns) * 10000;

opts.runCUCBAlg=0; % run CUCB model as baseline
opts.useCUCBCascades=0; % Use cascade simulation from CUCB by default
opts.isContextual=1;
opts.showSeeds=1;

models={'TensorUCB','Random'}


opts.rank=5; % 1,2,3,4,5
opts.lambda=1e-1;
opts.c=0.1;
opts.sigma=1; % sigma^2
opts.delta=0.9;

opts.eps = 1e-1;
opts.delta = 0.5;
opts.R=0.5;

opts.oracleType=1;
opts.pmax=0.2;
opts.lapreg=1;
opts.q=0.25;

opts.temp_dir = strcat('./temp/',num2str(posixtime(datetime('now')) * 1e6));
mkdir(opts.temp_dir);

% = 1 for IC; = 2 for LT
opts.diffusionModel=1;
% spread computation model = 1 for IC, = 2 for LT, = 3 for both
opts.spreadComputationModel = 1;

rewardFigName = '';
cumrewardFigName = '';
cumregretFigName = '';
avgregretFigName = '';

fname=sprintf('Contextual_%s_K%s_d%s_c%s_nRuns%s_nIters%s_%s',opts.dataset,num2str(opts.K),num2str(opts.d),num2str(opts.c),num2str(opts.nRuns),num2str(opts.nIters),opts.uniqueId)
% fname=['Contextual_' opts.dataset '_K' num2str(opts.K) '_d' num2str(opts.d) '_c' num2str(opts.c) '_nRuns' num2str(opts.nRuns) '_nIters' num2str(opts.nIters) '_' opts.uniqueId];
switch opts.dataset
    case 'digg'
        opts.graphType=1;
        opts.n=2843;
end
if opts.runCUCBAlg || opts.useCUCBCascades
    CUCB_regrets=zeros(opts.nRuns,opts.nIters);
    CUCB_spread=zeros(opts.nRuns,opts.nIters);
end
for l=1:length(models)
    result{l}.regrets=zeros(opts.nRuns,opts.nIters);
    result{l}.rewards=zeros(opts.nRuns,opts.nIters);
    result{l}.l2error=zeros(opts.nRuns,opts.nIters);
    result{l}.runtime=zeros(opts.nRuns,1);
end

% Read graph data
net = readGraphData(opts.dataset,opts.graphType,opts);
X = net.X;
n = net.commSize;
opts.n=n;
net.A(1:n+1:end)=zeros(n,1); % No self-loops

sel_item = zeros(opts.nIters,1);
for iter =1:opts.nIters
    s_id = datasample(1:length(net.P_item(:,2)),1,'Weights',net.P_item(:,2));
    sel_item(iter) = net.P_item(s_id,1);
end
disp(opts)
for runId=1:opts.nRuns
    fprintf('---------------- Run %d----------------------------\n', runId);
    opts.run=runId;
    rng(runId)
    % Initialization
    model = initParams(models, opts);
    % Run CUCB
    if opts.runCUCBAlg || opts.useCUCBCascades
        [net.cascades,CUCB_spread(runId,:),CUCB_time] = runCUCB(opts);
        fprintf('Done\n');
    end
    
    for iter = 1:opts.nIters
        opts.iter=iter;
        opts.selItem = sel_item(iter);
        fprintf('Round %d-%d ... \n',runId,iter);
        runtimeLog=[ '(Time Taken): '] ;
        spreadLog=[ '(Inf. Spread): '] ;
        regretLog=[ '(Cum .Regret): '];
        l2Log=[ '(L2Error): '] ;
        cumLog=[ '(Avg. Regret): '];
        
        [z,net.Pt] = writeGraphFile(net,opts,false,opts.temp_dir);

        net.Pt(1:n+1:end)=ones(n,1); % Each node can influence itself
        S_true = selectSeeds(net.A,net.Pt,opts.K,opts.oracleType,opts.temp_dir); % Select True Seeds
        
        
        % Generate information/influence cascade for the current timestep
        if opts.useCUCBCascades
            temp = net.cascades{iter};
            temp = reshape( temp, [2 size(temp,2)/2])';
            net.draw = sparse(temp(:, 1), temp(:, 2), 1, opts.n,opts.n); % can be IC or LT
        else
            net.draw = simulateCascade(net.A,net.Pt); % IC only
        end
        net.draw(1:n+1:end)=ones(n,1); % each node can influence itself
        
        % Calculate True Spread for the given cascade
        [net.spread,net.activeNodes,net.activeEdges] = calculateSpread(S_true,net.draw);
        if opts.showSeeds
            fprintf(sprintf('%25s: <> %s <>\n','Truth',strjoin(string(S_true),'  ')));
        end
        
        for it = 1:length(models)
            model{it}.id=models{it};
            model{it}.opts.iter = iter;
            modelName = string(models{it}).split('_');
            
            net.z=z;
            net.X=[repmat(z,1,opts.n);X];
            %net.X = cell2mat(cellfun(@(x) reshape(x*z',100,1),num2cell(X,1),'UniformOutput',false));
            switch modelName
                case 'TensorUCB'
                    net.z=z;
                    net.X=X;
            end
            
            model{it}.opts.iter=iter;
            % Learn Influence Maximization model
            tStart = tic;
            switch modelName
                case 'Random'
                    model{it} = Random(model{it},net,model{it}.opts);
                case 'TensorUCB'
                    model{it} = TensorUCB(model{it},net,model{it}.opts);
                otherwise
                    warning('Unexpected Model type %s. Cannot run CIM.',models{it})
            end
            tEnd = toc(tStart);
            % Gather Results
            reg=(net.spread - model{it}.spread);
            if reg<0
                reg=0;
            end
            
            diff_l2 = norm(net.Pt-model{it}.Phat,'fro');
            result{it}.runtime(runId)=result{it}.runtime(runId) + tEnd;
            result{it}.l2error(runId,iter)=diff_l2;
            result{it}.regrets(runId,iter)=reg;
            result{it}.rewards(runId,iter)=model{it}.spread;
            
            runtimeLog=[runtimeLog model{it}.id ' = ' num2str(result{it}.runtime(runId)/iter,'%0.2f') ', '];
            spreadLog=[spreadLog model{it}.id ' = ' num2str(model{it}.spread,'%0.2f') ', '];
            regretLog=[regretLog model{it}.id ' = ' num2str(sum(result{it}.regrets(runId,:)),'%0.2f') ', '];
            cumLog=[cumLog model{it}.id ' = ' num2str(sum(result{it}.regrets(runId,:))/iter,'%0.2f') ', '];
            l2Log=[l2Log model{it}.id ' = ' num2str(diff_l2,'%0.2f') ', '];
            
            if opts.showSeeds
                fprintf(sprintf('%25s: <> %s <>\n',models{it},strjoin(string(sort(model{it}.S)),'  ')));
            end
        end
        
        if opts.cv && opts.cv_iters == iter
            %             opts.cv_best_model(runId) = 0;
            %             opts.cv_best_score(runId) = 10000;
            for l = 1:length(opts.cv_models)
                it = opts.cv_models(l);
                tot_regret = sum(result{it}.regrets(runId,:))/iter;
                if tot_regret < opts.cv_best_score(runId)
                    opts.cv_best_model(runId) = it;
                    opts.cv_best_score(runId) = tot_regret;
                end
            end
        end
        
        if opts.runCUCBAlg || opts.useCUCBCascades
            CUCB_regrets(runId,iter) = (net.spread  - CUCB_spread(runId,iter));
            spreadLog=[spreadLog 'CUCB = ' num2str(CUCB_spread(runId,iter),'%0.2f') ', '];
            regretLog=[regretLog 'CUCB = ' num2str(sum(CUCB_regrets(runId,:)),'%0.2f')];
            cumLog=[cumLog 'CUCB = ' num2str(sum(CUCB_regrets(runId,:))/iter,'%0.2f')];
        end
        
        spreadLog=[spreadLog 'True = ' num2str(net.spread)];
        
        disp((runtimeLog));
        disp((spreadLog));
        disp((regretLog));
        disp((l2Log));
        disp((cumLog));
    end
    workspace_name = sprintf('./Results/%s_runId%s_workspace.mat',fname, num2str(runId));
%     workspace_name = ['./Results/' fname '_runId' num2str(runId) '_workspace.mat'];
    dispOut = [(runtimeLog) (spreadLog) (regretLog) (l2Log)  (cumLog) ];
    
    save(workspace_name,'opts','dispOut','result');
end

if opts.nRuns > 1
    modelnames=models;
    rewards = [];
    l2error = [];
    cumrewards=[];
    cumregrets=[];
    avgregrets=[];
    lineStyles = {':','-','--','-.'};

    for l=1:length(models)
        rewards=[rewards mean(result{l}.rewards,1)'];
        l2error=[l2error mean(result{l}.l2error,1)'];
        cumrewards=[cumrewards mean(cumsum(result{l}.rewards,2),1)']; % mean across runs
        cumregrets=[cumregrets mean(cumsum(result{l}.regrets,2),1)'];
        avgregrets=[avgregrets mean(cumsum(result{l}.regrets,2),1)'./(1:opts.nIters)'];
    end

    if opts.cv
        best_rewards=[];
        best_regrets=[];
        best_l2error=[];
        for runId=1:opts.nRuns
            bm = opts.cv_best_model(runId);
            best_l2error=[best_l2error;result{bm}.l2error(runId,:)];
            best_rewards = [best_rewards;result{bm}.rewards(runId,:)];
            best_regrets = [best_regrets;result{bm}.regrets(runId,:)];
        end
        modelnames = ['Best_TensorUCB', modelnames];
        rewards=[mean(best_rewards,1)' rewards];
        l2error=[mean(best_l2error,1)' l2error];
        cumrewards=[mean(cumsum(best_rewards,2),1)' cumrewards];
        cumregrets=[mean(cumsum(best_regrets,2),1)' cumregrets];
        avgregrets=[mean(cumsum(best_regrets,2),1)'./(1:opts.nIters)' avgregrets];
    end

    if opts.runCUCBAlg || opts.useCUCBCascades
        modelnames{end+1}='CUCB';
        rewards=[rewards mean(CUCB_spread,1)'];
        cumrewards=[cumrewards mean(cumsum(CUCB_spread,2),1)'];
        cumregrets=[cumregrets mean(cumsum(CUCB_regrets,2),1)'];
        avgregrets=[avgregrets mean(cumsum(CUCB_regrets,2),1)'./(1:opts.nIters)'];
    end


    l2errorFigName = sprintf('./figures/%s_l2errorFigv3.fig',fname);
    rewardFigName  = sprintf('./figures/%s_rewardFigv3.fig',fname);
    cumrewardFigName = sprintf('./figures/%s_cumRewardFigv3.fig',fname); 
    cumregretFigName = sprintf('./figures/%s_cumRegretFigv3.fig',fname);
    avgregretFigName = sprintf('./figures/%s_avgRegretFigv3.fig',fname);
    
    workspace_name = sprintf('./Results/%s_workspace.mat',fname);
    save(workspace_name,'opts','result','rewards','cumrewards','cumregrets','avgregrets');

    plotcolors = distinguishable_colors(length(modelnames));
    plotResults(l2error,'L2Error',modelnames(1:end-1),plotcolors(1:end-1,:),lineStyles,l2errorFigName);
    plotResults(rewards,'Rewards',modelnames,plotcolors,lineStyles,rewardFigName);
    plotResults(cumrewards,'Cumulative Rewards',modelnames,plotcolors,lineStyles, cumrewardFigName);
    plotResults(cumregrets,'Cumulative Regret',modelnames,plotcolors,lineStyles,cumregretFigName);
    plotResults(avgregrets,'Average Regret',modelnames,plotcolors,lineStyles,avgregretFigName);

    
end
rmdir(opts.temp_dir, 's')
