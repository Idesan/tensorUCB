function test_bfs
end
