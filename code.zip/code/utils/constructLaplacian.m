function [L] = constructLaplacian(A,lapreg)

n = size(A,1);
d = sum(A,2);
D = sparse(diag(d));
L = D - A;

L = L + lapreg * speye(n);

end
