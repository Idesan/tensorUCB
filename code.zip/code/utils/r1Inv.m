function [AInv] = r1Inv(AInv,x,y,a)
%R1INV Rank-1 Inverse of a matrix given the x and y vectors, get the
%inverse of the A + a*xy' from the inverse of A

if ~exist('a','var')
    c = 1.0;
else
    c = 1/a;
end
temp = AInv*y; % d x 1 vectr
AInv = AInv - ((temp*temp')/(c + x'*temp));
end

