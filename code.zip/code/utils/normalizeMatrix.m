function [X,normX] = normalizeMatrix(X)
%NORMALIZEDATA normalize the given matrix along the row
%   X is a d x n matrix, then output X will be normalized along the column,
%   normX is a row Vector
d=size(X,1);
normX=sum((X).^2,1);
X = X.* repmat(1./sqrt(normX),d,1);
end

