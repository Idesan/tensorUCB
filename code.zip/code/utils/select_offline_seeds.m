function [S] = select_offline_seeds(A,P,K,diffusion_model)

num_nodes = length(P) + 1; 
num_edges = nnz(P);  
% construct graph_ic.inf
%[i,j,val] = find(P);
%data_dump = [i,j,val];
%dlmwrite('./graph_ic.inf',[i j val],' ');

% construct attribute file
f = fopen('./attribute.txt','w');
fprintf(f,'%s\n',['n=' num2str(num_nodes)]);
fprintf(f,'%s',['m=' num2str(num_edges)]);
fclose(f);

% call offline oracle
if diffusion_model == 1
	cmd = ['./Offline-Oracle/tim -model IC -dataset ./ -epsilon 0.5 -k ' num2str(K)];
elseif diffusion_model == 2
	cmd = ['./Offline-Oracle/tim -model LT -dataset ./ -epsilon 0.5 -k ' num2str(K)];
end 

[status, s] = system(cmd);
l = strsplit(s,' ');
S = str2double(l(1:K));

% avoid selecting zero as seed
S( S == 0) = 1;

S = S';

end


