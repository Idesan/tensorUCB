function [net] = readGraphData(dataset,graphType,opts)


net.graphType=graphType;
net.graph=dataset;
net.numComponents=5; % needed for synthetic data
n=4039; % exact value needed for synthetic data

fprintf('Reading Graph %s ...',net.graph);
[net.A,net.P,net.n,net.commSize,net.P_itemtopic,net.P_item,net.P_topic] = createGraph(n,opts.pmax,net.numComponents,net.graphType,opts.use_cuda);
fprintf('Done\n');

% Construct the bottom d singular vectors from Laplacian and normalized
fprintf('Generating node-level features from Laplacian Matrix ...');
net.L = constructLaplacian(net.A,opts.lapreg);
[U,Sigma,~] = svds(net.L,opts.d,'smallest');
%net.X=U';
%normX=sum((U').^2,1);
net.d=opts.d;
net.Sigma=Sigma;
%net.X = U'.* repmat(1./sqrt(normX),opts.d,1);
[net.X,normX]=normalizeMatrix(U');
% Optional scaling
scaleMat=diag(1./sqrt(diag(net.Sigma)));
%net.X = scaleMat*U';

% Edge Features - Too Big
% [d,n] = size(net.X);
% edgeX = zeros(d^2,n,n);
% for i=1:n
%     for j=1:n
%         op = net.X(:,i) * net.X(:,j)';
%         edgeX(:,j,i) = op(:);
%     end
% end
% net.edgeX=edgeX;
fprintf('Done\n');

net.normX = sum(abs(net.X).^2,1);
end

