function S = selectSeeds(A,P,K,oracleType,graph_loc)

n=size(P,1);

if oracleType==1
    % Project it less than 1.0 to work
    Ap = A;
    Ap(1:n+1:end)=ones(n,1);
    P=min(max(P,0),0.95).*Ap;
%     rand_str = num2str(posixtime(datetime('now')) * 1e6);
%     graph_loc = strcat('./temp/',rand_str);
%     mkdir(graph_loc);
    % construct graph_ic.inf
    [row,col,v] = find(P);
    dlmwrite(strcat(graph_loc,'/graph_ic.inf'),[row col v], 'delimiter', ' ');
    num_nodes = length(P) + 1;
    num_edges = nnz(P);
    
    if num_edges>0
        % construct attribute file
        
        f = fopen(strcat(graph_loc,'/attribute.txt'),'w');
        fprintf(f,'%s\n',['n=' num2str(num_nodes)]);
        fprintf(f,'%s',['m=' num2str(num_edges)]);
        fclose(f);
        
        cmd = ['./Oracle/tim -model IC -dataset ' graph_loc '/ -epsilon 0.5 -k ' num2str(K)];
        
        [status, s] = system(cmd);
        l = strsplit(s,' ');
        if status==1 || length(l)<K
            fprintf('Cannot select K seeds. Selecting randomly.');
            S = randsample(n,K)';
        else
            S = str2double(l(1:K));
        end
    else
        fprintf('Cannot select K seeds. No edges. Selecting randomly.');
        S = randsample(n,K)';
    end
    % avoid selecting zero as seed
    S( S == 0) = 1;
    
    S = S';
%     rmdir(graph_loc, 's')
elseif oracleType==2
    
    S = zeros(K,1);
    prev_spread = 0;
    
    % initialize marginal gain
    MG = zeros(n,2);
    for k = 1:K
        
        if k == 1
            
            MG = [(1:n)' sum(P,2)];
            MG = sortrows(MG,2);
            
        else
            
            %going in the order of marginal gains
            for i = 1:n-k
                
                % take top node
                selected_node = MG(end,1);
                
                % recompute the marginal gain
                MG(end,2) = sum(bsxfun(@max, P(selected_node,:),temp),2) - prev_spread;
                
                % check if its still better than the second
                if MG(end,2) >= MG(end-1,2)
                    
                    % if yes, just select that node
                    % fprintf('Number of evaluations = %d\n', i);
                    prev_spread = MG(end,2) + prev_spread;
                    break;
                    
                else
                    
                    % if no, re-sort and then pick top
                    val = MG(end,2);
                    a = MG(:,2);
                    b = MG(:,1);
                    pos = binarySearch(a,n-1,val);
                    a = [a(1:pos-1) ; val ; a(pos:end-1)];
                    b = [b(1:pos-1) ; selected_node ; b(pos:end-1)];
                    MG = [b a];
                    
                end
                
            end
            
        end
        
        S(k) = MG(end,1);
        
        if k == 1
            temp = P(S(1:k),:);
        else
            temp = max(P(S(1:k),:));
        end
        
        % so that we don't select the same node again
        MG(end,2) = -1;
        MG = circshift(MG,1);
        
    end
    
else % Degree Discount Oracle
    S = [];
    Pmat = P;
    Pmat(1:n+1:end)=ones(n,1);
    MG = [(1:n)' sum(Pmat,2)];
    MG = sortrows(MG,2);
    for k = 1:K
        S = [S;MG(end,1)];
        MG(end,2) = -1;
        MG = circshift(MG,1);
       
        % compute num of influencers 
        [d,~,~] = bfs(A,S(end));
        activated = (d == 1); % Column vector, immediate neighbor to S_k
        activated = activated(MG(k+1:end,1));
        % (1-Pmat(MG(1:k,1),MG(k:end,1))');
        multTerm = activated;
        for jj = 1:k
            multTerm = multTerm .* (1-Pmat(MG(jj,1),MG(k+1:end,1))');
        end
        sumTerm = sum(Pmat(MG(k+1:end,1),MG(k+1:end,1)),2);
        updProb = multTerm.*sumTerm;
        MG(logical(activated),2) = updProb(logical(activated));
        MG(k+1:end,:) = sortrows(MG(k+1:end,:),2);
        
    end
    S = full(S);
end