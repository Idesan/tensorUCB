function [model] = initParams(models,opts)
%INITPARAMS Summary of this function goes here
%   Detailed explanation goes here
for l=1:length(models)
    modelName = strsplit(models{l} ,'_');
    if length(modelName)==2
        opts.rank = str2double(modelName(2));
        modelName = modelName(1);
    end
    model{l}.S=zeros(opts.K,1);
    model{l}.Phat = zeros(opts.n);
    model{l}.Phat(1:opts.n+1:end)=ones(opts.n,1);
    model{l}.opts=opts;
    use_cuda = opts.use_cuda;
    
    switch modelName{1}
        case 'IMFB'
            model{l}.icov_in=(1.0/opts.lambda) * speye(opts.n*(opts.d+opts.d1),opts.n*(opts.d+opts.d1));
            model{l}.icov_out=(1.0/opts.lambda) * speye(opts.n*(opts.d+opts.d1),opts.n*(opts.d+opts.d1));
            model{l}.bIn=randn((opts.d+opts.d1) * opts.n,1);
            model{l}.bOut=randn((opts.d+opts.d1) * opts.n,1);
            model{l}.alphaIn=opts.sigma*reshape(model{l}.icov_in*model{l}.bIn,[(opts.d+opts.d1) opts.n]);
            model{l}.alphaOut=opts.sigma*reshape(model{l}.icov_out*model{l}.bOut,[(opts.d+opts.d1) opts.n]);
        case 'DIlinUCB'
            model{l}.icov_x=(1/opts.lambda) * speye(opts.n); % n x n matrix
            model{l}.alpha=zeros((opts.d+opts.d1),opts.n);
            model{l}.b=zeros((opts.d+opts.d1) * opts.n,1);
            model{l}.freq = zeros(opts.n,1) * 1e-3;
        case 'IMLinUCB'
            model{l}.icov_x=(1/opts.lambda) * speye((opts.d+opts.d1)^2);
            model{l}.alpha = zeros((opts.d+opts.d1)^2,1);
            model{l}.b=zeros((opts.d+opts.d1)^2,1);
        case 'BilinUCB'
            model{l}.icov_s=(1/opts.lambda) * speye(opts.d+opts.d1);
            model{l}.icov_x=(1/opts.lambda) * speye(opts.d+opts.d1);
            model{l}.alpha = zeros((opts.d+opts.d1),(opts.d+opts.d1));
            model{l}.b=zeros((opts.d+opts.d1),(opts.d+opts.d1));
        case {'TensorUCB','COIN'}
            %model{l}.opts.c=0.01;
            U=(zeros(opts.d,model{l}.opts.rank));
            V=(zeros(opts.d,model{l}.opts.rank));
            if opts.isContextual
                W=(zeros(opts.d1,model{l}.opts.rank));
                cov2 = opts.lambda * speye(opts.d1);
            end
            cov1 = opts.lambda * speye(opts.d);
            
            
            for r=1:model{l}.opts.rank
                if opts.rank>=1
                    model{l}.bU{r}=randn(opts.d,1);
                    model{l}.bV{r}=randn(opts.d,1);
                    if opts.isContextual
                        model{l}.bW{r}=randn(opts.d1,1);
                    end
                else
                    model{l}.bU{r}=zeros(opts.d,1);
                    model{l}.bV{r}=zeros(opts.d,1);
                    if opts.isContextual
                        model{l}.bW{r}=zeros(opts.d1,1);
                    end
                end
                icov_u{r}=(1/opts.lambda) * speye(opts.d);
                icov_v{r}=(1/opts.lambda) * speye(opts.d);
                if opts.isContextual
                    icov_w{r}=(1/opts.lambda) * speye(opts.d1);
                end
                U(:,r)=mvnrnd(zeros(opts.d,1),cov1);
                V(:,r)=mvnrnd(zeros(opts.d,1),cov1);
                if opts.isContextual
                    W(:,r)=mvnrnd(zeros(opts.d1,1),cov2);
                end
                
                cov_u{r} = opts.lambda * speye(opts.d);
                cov_v{r} = opts.lambda * speye(opts.d);
                if opts.isContextual
                    cov_w{r} = opts.lambda * speye(opts.d1);
                end
            
%                 U(:,r)=cov_u{r}\model{l}.bU{r};
%                 V(:,r)=cov_v{r}\model{l}.bV{r};
%                 W(:,r)=cov_w{r}\model{l}.bW{r};
                
            end
            U=normalizeMatrix(U);
            V=normalizeMatrix(V);
            if opts.isContextual
                W=normalizeMatrix(W);
            end
            
            model{l}.U=U;
            model{l}.V=V;
            
            model{l}.icov_u=icov_u;
            model{l}.icov_v=icov_v;
            
            model{l}.cov_u=cov_u;
            model{l}.cov_v=cov_v;
            if opts.isContextual
                model{l}.W=W;
                model{l}.icov_w=icov_w;
                model{l}.cov_w=cov_w;
            end
    end
end

end

