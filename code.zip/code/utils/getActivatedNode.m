function [all_activated,activeNodeList] = getActivatedNode(activatedNodes)
% Get the activated node list based on the 

[K,n]=size(activatedNodes);

%initialize all activated set
all_activated = zeros(1,n);

% activated contains indices of nodes reachable from s
for j = 1:K
    all_activated = bitor(all_activated,activatedNodes(j,:));
end
activeNodeList = find(all_activated ~= 0); % Activated Node ids
end

