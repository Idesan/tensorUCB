function [spread,activatedNodes,activatedEdges] = calculateSpread(S,draw)

n = size(draw,1);
K = size(S,1);

%initialize activated set
activatedNodes = zeros(K,n);
activatedEdges = zeros(n,n);


%check reachability from any source node
St=unique(S);
pred = [];
for j = 1:length(St)
    [d,~,pred_k] = bfs(draw,St(j));
    activatedNodes(j,:) = (d ~= -1);
    pred = [pred;pred_k];
end
idx = sub2ind([n n],pred(:,2),pred(:,1));
activatedEdges(idx)=1;

[all_activated,~] = getActivatedNode(activatedNodes);

spread = nnz(all_activated);
% active = find(all_activated ~= 0); % Activated Node ids

end
