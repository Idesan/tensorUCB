function [ cascades ] = processCascades( fname, T )
f = fopen(fname,'r');

cascades = {};
t = 0;

for t = 1:T
    s = fgetl(f);
    if s ==-1
        continue;
    end
    l = strsplit(s,',');
    temp = str2double(l);
    temp(end) = [];
    cascades{t} = temp;
end

fclose(f);

end

