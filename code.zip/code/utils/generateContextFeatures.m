function [Z,ctxActives] = generateContextFeatures(X,opts)
%GENERATECONTTEXTFEATURES Summary of this function goes here
%   Detailed explanation goes here
Z=[];
ctxActives=[];
fprintf('Generating Contextual Environment ...\n');
[contextClusterId,centroids]=kmeans(X',opts.nClusters);
%poolActives=randsample(opts.n,poolSize);%selectSeeds(net.P,poolSize,opts.oracleType);%
%poolActives=poolActives(5:end);
for it = 1:10
    % Select ctxNodes% context-specific nodes for each iteration
    ctxAct=randsample(opts.nClusters,3);
    ctxActive=contextClusterId==ctxAct(1);
    for s=2:3
        ctxActive=bitor(ctxActive,contextClusterId==ctxAct(s));
    end
    
    % Generate Context Vectors
    z=sum(X(:,ctxActive),2);
    %z=sum(centroids(ctxAct,:));
    z=normalizeMatrix(z);
    ctxActives=[ctxActives ctxActive];% nCtxActives x nIters
    Z=[Z z]; % d x nIters
end
end

