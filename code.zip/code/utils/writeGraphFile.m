function [z,P] = writeGraphFile(net,opts,displayMode,graph_loc)


% cmd = strcat(['cp ./Data/' opts.dataset '/attribute.txt ' graph_loc]);
cmd = sprintf('cp ./Data/%s/attribute.txt %s',opts.dataset,graph_loc);
% disp(cmd)
system(cmd);

z = ones(opts.d,1)/opts.d;
if iscell(net.P)
    if isfield(opts, 'selItem')
        sel_item = opts.selItem;
    else
        s_id = datasample(1:length(net.P_item(:,2)),1,'Weights',net.P_item(:,2));
        sel_item = net.P_item(s_id,1);
    end
    if true
        fprintf('Selected item for activation: %d\n',sel_item);
    end
    item_wt = net.P_itemtopic(net.P_itemtopic(:,1)==sel_item,2:end);
    % item_wt = (1-1e-2)*item_wt + 1e-2;
    if displayMode
        disp(item_wt)
    end
    P = item_wt(1)*net.P{1};
    for k=2:length(net.P)
        if item_wt(k) > 1e-2
            P = P+ item_wt(k)*net.P{k};
        end
    end
    z = item_wt';
    
    [row,col,val] = find(P);
%     dlmwrite('./graph_ic.inf',[row col val], 'delimiter', '\t');
else
    [row,col,val] = find(net.P);
    P = net.P;
end
dlmwrite(strcat(graph_loc,'/graph_ic.inf'),[row col val], 'delimiter', '\t');
end

