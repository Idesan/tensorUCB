function [A,P,n,component_sizes,P_itemtopic,P_item,P_topic] = createGraph(n,pmax, C,type,use_cuda)

P_item = [];
P_topic = [];
P_itemtopic = [];


if type == 1
    
    
    p_len = 10;
    fname = 'Data/digg/graph_ic_topic.inf';
    edges = dlmread(fname);
    
    fname = 'Data/digg/item_topic_distribution.txt';
    P_itemtopic = dlmread(fname);
    fname = 'Data/digg/topic_prior.txt';
    temp = dlmread(fname);
    P_topic = temp(:,2);
    fname = 'Data/digg/items_prior.txt';
    P_item = dlmread(fname);
    
    nodeList = sort(unique([edges(:,1);edges(:,2)]));
    n = length(nodeList);
    I = arrayfun(@(x) find(nodeList==x,1), edges(:,1));
    J = arrayfun(@(x) find(nodeList==x,1), edges(:,2));
    
    A = sparse(n,n);
    
    P = cell(p_len,1);
    for k = 1:p_len
        P{k}=sparse(n,n);
    end
    
    for e = 1:size(edges,1)
        A(I(e),J(e)) = 1;
        e_prob = edges(e,3:end);
        e_prob(e_prob<1e-2)=0.0;
%         e_prob = e_prob/sum(e_prob);
        for k=1:p_len
            P{k}(I(e),J(e)) = pmax*e_prob(k);
        end
    end
    component_sizes = n; 
else
    error('Not a valid graph type.');
    
end
end

