function [Y,freq] = getReward(draw,S, nodeOnly)
%GETREWARD Get node or edge-level feedback for the current IM round

[n,~]=size(draw);
K = length(S);
freq = zeros(n,1);
if nodeOnly ==1 % return node-level feedback
    Y=zeros(K,n); % each row corr to influencers, column to influencee
    for j = 1:K
        %check reachability from source node
        s = S(j);
        [ob,~,~] = bfs(draw,s);

        Y(j,:) = (ob ~= -1);

        % update frequency
        freq(s) = freq(s) + 1;

    end
else % return edge-level feedback
    Y=zeros(n,n); % each row to influencers, column to influencee
    pred =[];
    for j = 1:K
        %check reachability from source node
        s = S(j);
        [ob,~,pred_k] = bfs(draw,s);
        pred = [pred;pred_k];

    end
    idx = sub2ind([n n],pred(:,2),pred(:,1));
    Y(idx)=1;
    % update frequency
    freq = freq + sum(Y,2);
end
end

