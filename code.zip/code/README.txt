This code is prepared for the paper titled 'Sequential Social Targeting with Variational Tensor Regression.' The authors reserve all legal rights.



---------------------------------------------
Instruction
---------------------------------------------
1) Please make sure the Source code in Oracle folder is compiled and create an executable for your machine.

2) Create a 'temp' folder

3) Run the matlablab script:
run_context_script for the digg dataset
